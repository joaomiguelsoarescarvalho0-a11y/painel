# Mira Demo (Android)

Projeto demonstrativo em Java para Android. A tela simula uma arena com alvos gráficos, um indicador de FOV e um controle de suavização.

**Não é um cheat e não interage com Free Fire ou qualquer outro jogo.** Não lê a tela de outros aplicativos, não injeta código e não move a mira de jogos.

## Como gerar o APK

1. Extraia `MiraDemoAndroid.zip`.
2. Abra o diretório `MiraDemoAndroid` no Android Studio.
3. Aceite a instalação/sincronização do Gradle e dos componentes Android solicitados.
4. Aguarde o Gradle Sync terminar.
5. Use **Build > Build APK(s)**.
6. O APK de depuração normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos

- Android Studio recente
- JDK compatível com Android Gradle Plugin 8.6.1 (JDK 17 recomendado)
- Android SDK Platform 35

Este pacote contém o código-fonte do projeto. Ele não contém um APK já compilado.
