package com.example.mirademo;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int fov = 120;
    private int smooth = 25;
    private TextView fovValue;
    private TextView smoothValue;
    private DemoArenaView arena;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().setStatusBarColor(Color.rgb(16, 16, 24));
        getWindow().setNavigationBarColor(Color.rgb(16, 16, 24));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(16, 16, 24));

        TextView title = text("MIRA DEMO", 24, Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, matchWrap());

        TextView subtitle = text("Simulador local — não se conecta a jogos", 13, 0xFFB8B8C8);
        root.addView(subtitle, matchWrap());

        arena = new DemoArenaView(this);
        LinearLayout.LayoutParams arenaParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        arenaParams.topMargin = dp(16);
        arenaParams.bottomMargin = dp(16);
        root.addView(arena, arenaParams);

        root.addView(text("Campo de visão (FOV)", 16, Color.WHITE), matchWrap());
        LinearLayout fovRow = new LinearLayout(this);
        fovRow.setGravity(Gravity.CENTER_VERTICAL);
        fovValue = text("120", 14, 0xFFD8C7FF);
        SeekBar fovBar = new SeekBar(this);
        fovBar.setMax(300);
        fovBar.setProgress(fov);
        fovBar.setContentDescription("Ajustar campo de visão");
        fovRow.addView(fovBar, new LinearLayout.LayoutParams(0, dp(44), 1f));
        fovRow.addView(fovValue, new LinearLayout.LayoutParams(dp(48), dp(44)));
        root.addView(fovRow, matchWrap());
        fovBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                fov = Math.max(10, p);
                fovValue.setText(String.valueOf(fov));
                arena.setSettings(fov, smooth);
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        root.addView(text("Suavização", 16, Color.WHITE), matchWrap());
        LinearLayout smoothRow = new LinearLayout(this);
        smoothRow.setGravity(Gravity.CENTER_VERTICAL);
        smoothValue = text("25%", 14, 0xFFD8C7FF);
        SeekBar smoothBar = new SeekBar(this);
        smoothBar.setMax(100);
        smoothBar.setProgress(smooth);
        smoothBar.setContentDescription("Ajustar suavização");
        smoothRow.addView(smoothBar, new LinearLayout.LayoutParams(0, dp(44), 1f));
        smoothRow.addView(smoothValue, new LinearLayout.LayoutParams(dp(48), dp(44)));
        root.addView(smoothRow, matchWrap());
        smoothBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                smooth = p;
                smoothValue.setText(p + "%");
                arena.setSettings(fov, smooth);
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        TextView note = text("Os alvos e a mira são apenas gráficos de demonstração.", 12, 0xFF9D9DAE);
        note.setPadding(0, dp(10), 0, 0);
        root.addView(note, matchWrap());
        setContentView(root);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
