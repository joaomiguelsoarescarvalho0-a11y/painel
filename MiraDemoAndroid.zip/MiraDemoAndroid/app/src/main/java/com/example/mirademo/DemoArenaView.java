package com.example.mirademo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class DemoArenaView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int fov = 120;
    private int smooth = 25;

    public DemoArenaView(Context context) {
        super(context);
        setBackgroundColor(0xFF20202D);
    }

    public void setSettings(int newFov, int newSmooth) {
        fov = newFov;
        smooth = newSmooth;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        p.setStrokeWidth(2f);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFF6D5BA6);
        for (int i = 1; i < 6; i++) c.drawLine(0, h*i/6f, w, h*i/6f, p);
        for (int i = 1; i < 5; i++) c.drawLine(w*i/5f, 0, w*i/5f, h, p);

        float cx = w/2f, cy = h/2f;
        float radius = Math.min(w, h) * (0.12f + 0.30f * fov / 300f);
        p.setColor(0xAAAB8CFF);
        c.drawCircle(cx, cy, radius, p);

        drawTarget(c, w*0.28f, h*0.35f, 0xFF63D9A2);
        drawTarget(c, w*0.70f, h*0.42f, 0xFFFFC857);
        drawTarget(c, w*0.58f, h*0.72f, 0xFFFF7F9F);

        p.setColor(0xFFFFFFFF);
        p.setStrokeWidth(3f);
        c.drawLine(cx-13, cy, cx+13, cy, p);
        c.drawLine(cx, cy-13, cx, cy+13, p);

        p.setStyle(Paint.Style.FILL);
        p.setTextSize(13f);
        p.setColor(0xFFE0D8FF);
        c.drawText("FOV " + fov + "  •  suavização " + smooth + "%", 14, 24, p);
    }

    private void drawTarget(Canvas c, float x, float y, int color) {
        float size = 25f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f);
        p.setColor(color);
        c.drawRoundRect(new RectF(x-size, y-size*1.35f, x+size, y+size*1.35f),
            6f, 6f, p);
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(11f);
        c.drawText("ALVO", x-size, y+size*1.8f, p);
    }
}
